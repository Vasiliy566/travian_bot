Simple travian bot to automatically grade mani villages.

